package com.gabriel.jaya.cazarpatos

const val EXTRA_LOGIN = "EXTRA_LOGIN"

const val LOGIN_KEY = "LOGIN_KEY"
const val PASSWORD_KEY = "PASSWORD_KEY"
const val SHAREDINFO_FILENAME = "mySharedInformation.dat"