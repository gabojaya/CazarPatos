package com.gabriel.jaya.cazarpatos

data class Player (var username:String, var huntedDucks:Int){
    constructor():this("",0)
}